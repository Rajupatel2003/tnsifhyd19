package overriding;

public class A {
	public void display() {
		System.out.println("Class A Display");
	}
	public class B extends A{
		public void display() {
			System.out.println("Class B Display");
		}
	}
}