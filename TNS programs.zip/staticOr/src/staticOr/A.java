package staticOr;

public class A {
	public static void display() {
		System.out.println("Class A");
	}
}
