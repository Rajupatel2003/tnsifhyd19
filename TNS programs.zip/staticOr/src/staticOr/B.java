package staticOr;

public class B extends A {
	public static void display() {
		System.out.println("Class B");
	}
}
