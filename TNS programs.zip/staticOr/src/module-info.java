/**
 * 
 */
/**
 * 
 */
module staticOr {
}