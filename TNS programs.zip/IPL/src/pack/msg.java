package pack;

public class msg {

}
