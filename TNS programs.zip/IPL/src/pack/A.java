package pack;

public class A {
	public void msg()
	{
		System.out.println("hello A");
		
	}

	public static void main(String[] args) {
		msg m1=new msg();
		m1.msg();
		// TODO Auto-generated method stub

	}

}
