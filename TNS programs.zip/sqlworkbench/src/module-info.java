/**
 * 
 */
/**
 * 
 */
module sqlworkbench {
	requires java.sql;
}