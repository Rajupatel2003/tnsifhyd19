package com.method;

public class methodoverloading {

	public static void main(String[] args) {
		methodoverloading  m1=new methodoverloading( );
		m1.methodoverloading();
		
		
		]
				
		// TODO Auto-generated method stub

	}

}
