package or;

public class B extends A {
	public void diplay() {
		System.out.println("Class B");
	}
	public static void main(String[] args) {
		B b1=new B();
		b1.diplay();
	}

}
