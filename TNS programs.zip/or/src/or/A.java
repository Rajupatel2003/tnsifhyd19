package or;

public class A {
	public void diplay() {
		System.out.println("Class A");
	}
}
