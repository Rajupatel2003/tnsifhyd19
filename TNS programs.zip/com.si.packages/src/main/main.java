package main;

import pack.A;
import pack.C;
import Subpackage.D;

public class main {

	public static void main(String[] args) {
		A a1=new A();
		C c1=new C();
		D d1=new D();
		a1.msg();
		c1.msg();
		d1.msg();
		
	}

}
