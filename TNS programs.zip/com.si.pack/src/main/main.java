package main;

import IPL.RCB;
import IPL.CSK;
import IPL.SRH;
public class main {

	public static void main(String[] args) {
		RCB r1=new RCB();
		SRH s1=new SRH();
		CSK c1=new CSK();
		r1.batsman();
		r1.bowler();
		c1.batsman();
		c1.bowler();
		s1.batsman();
		s1.bowler();
	}

}
