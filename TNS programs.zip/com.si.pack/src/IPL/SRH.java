package IPL;

public class SRH {
	public void batsman() {
		System.out.println("Head");
	}
	public void bowler() {
		System.out.println("Bhuvi");
	}
}
