package IPL;

public class CSK {
	public void batsman() {
		System.out.println("Dhoni");
	}
	public void bowler() {
		System.out.println("Pathirana");
	}
}
