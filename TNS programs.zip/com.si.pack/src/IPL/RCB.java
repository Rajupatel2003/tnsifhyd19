package IPL;

public class RCB {
	public void batsman() {
		System.out.println("Virat Kohli");
	}
	public void bowler() {
		System.out.println("Siraj");
	}
}
